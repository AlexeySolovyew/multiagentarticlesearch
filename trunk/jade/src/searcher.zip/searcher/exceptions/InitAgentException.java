package searcher.exceptions;

public class InitAgentException extends Exception {

	public InitAgentException() {
		// TODO Auto-generated constructor stub
	}

	public InitAgentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InitAgentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InitAgentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
