package searcher.tests;

import searcher.SEBoot;
import junit.framework.TestCase;


public class SimpleSETests extends TestCase {
	
	public void bootSETest() { 
        //SEBoot.main(null);
  } 

}
